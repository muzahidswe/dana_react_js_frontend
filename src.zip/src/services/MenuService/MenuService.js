import axios from 'axios';
import { baseURL } from '../../constants/constants';

const MENU_LIST = baseURL+'menu-list';

export async function menuServiceByRole(role_id  , user_id) { 
    const token = localStorage.getItem('token');
    var formData = new FormData();
    formData.append('role_id',role_id);
    formData.append('user_id',user_id);
    const config = {
        headers: { 
            Authorization: `Bearer ${token}`,
            'content-type': 'application/json'
        },
    };
    return await axios.post(MENU_LIST,formData, config);
}