import logo from "./logo.svg";
import "./App.css";
import React, { lazy, Suspense, useEffect, useState } from "react";
import { Redirect, Route, Switch } from "react-router-dom";
import auth from "./services/authService";
import Root from "./components/common/Root";
import LoginCheckRoute from "./components/common/loginCheckRoute";
import ProtectedRoute from "./components/common/protectedRoute";
import Footer from "./components/common/footer";
import Myprofile from "./components/common/Myprofile";
import SideBar from "./components/sideBar";
import Login from "./components/login";
import TopBar from "./components/topBar";
import HeaderMobile from "./components/headerMobile";
import './fonts/Nimbus/Nimbus.otf';
import CommonLogin from './components/CommonLogin';
import InfoUpload from "./components/UploadInformation/Distributor/distributorInfoUpload";
import SalesAgentUpload from "./components/UploadInformation/SalesAgent/SalesAgentUpload";
import RetailerUpload from "./components/UploadInformation/Retailer/RetailerUpload";
import DisbrushmentUpload from "./components/UploadInformation/Disbrusment/DisbrushmentUpload";
import ManufactureInfoUpload from "./components/UploadInformation/Manufacture/ManufactureInfoUpload";
import SupervisorInfoUpload from "./components/UploadInformation/Supervisor/SupervisorInfoUpload";



function App() {
  const [user, setUser] = useState();

  useEffect(() => {
    const user = auth.getCurrentUser();
    setUser(user);
  }, []);

  return (
    <div className="App">
    <Suspense fallback={<div>Loading...</div>}>
    <HeaderMobile />
    <LoginCheckRoute path="/login" component={Login} />
    <Route path="/common_login" exact component={CommonLogin} />
        <div className="d-flex flex-column flex-root">
            <div className="d-flex flex-row flex-column-fluid page">
              {user && <SideBar />}
                <div
                className="d-flex flex-column flex-row-fluid wrapper"
                id="kt_wrapper"
                >
                {user && <TopBar />}
                  <Switch>

                      {/* MyProfile information */}

                      <ProtectedRoute path="/myProfile" component={Myprofile} />

                      {/* MyProfile information */}

                      {/* upload information */}

                      <ProtectedRoute path="/upload-manufacturer-onboarding-data" component={InfoUpload} />
                      <ProtectedRoute path="/upload-sales-agent-onboarding-data" component={SalesAgentUpload} />
                      <ProtectedRoute path="/retailer-upload-information" component={RetailerUpload} />
                      <ProtectedRoute path="/upload-distributor-onboarding-data" component={DisbrushmentUpload} />
                      <ProtectedRoute path="/upload-manufacture-information" component={ManufactureInfoUpload} />
                      <ProtectedRoute path="/upload-distributor-supervisor-onboarding-data" component={SupervisorInfoUpload} />

                      {/* upload information */}

                      <Route path="/" exact component={Root} />

                    </Switch>
                </div>
            </div>
        </div>
    </Suspense>
    </div>
    );
}

export default App;
