//export const baseURL = "http://192.168.0.27:8989/";
// export const frontURL = "http://192.168.0.27:3001/";
// export const baseURL = "https://unnoti.net:8989/";
export const baseURL = "http://192.168.20.14:9999/";
export const accountFormUrl =
"http://192.168.20.14/ipdc_dana/dana_backend/public/account_form/";

export const nidImageBaseUrl =
"http://192.168.20.14/home/unnoti/public_html/ipdc_dana/dana_backend/public/outlet_documents/";
