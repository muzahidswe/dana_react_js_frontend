import React from "react";

function Dashboard(props) {
  return (
    <div style={{ minHeight: "83vh" }}>
      <h1>Dashboard</h1>
    </div>
  );
}

export default Dashboard;
